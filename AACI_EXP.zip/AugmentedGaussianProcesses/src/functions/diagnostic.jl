### Make a series of diagnotics when the convergence fails


function modeldiagnostic(model::AbstractGP)
    #TODO Check kernel matrix is valid (appropriate lengthscale, good conditioning)
    cond
    #TODO Check for other possible issues
end
